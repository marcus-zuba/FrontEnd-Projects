<?php
$dbhost="localhost";
$dbuser="root";
$dbpass="";
$dbname="banco-dos-piratas";
$con = mysqli_connect($dbhost,$dbuser,$dbpass) or die(mysql_error());
$sel = mysqli_select_db($con,$dbname);
 ?>
<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title>Controle de Estoque dos Tesouros</title>
    <link rel="stylesheet" href="estilos.css">
    <link rel="icon" href="calice.ico">
  </head>
  <body>
    <h1>Gerenciador de Tesouros</h1>
    <table>
      <caption>Estes são os tesouros acumulados do Barba-Ruiva em suas aventuras</caption>
      <thead>
        <tr>
          <th>Tesouro</th>
          <th>Nome</th>
          <th>Valor unitário</th>
          <th>Quantidade</th>
          <th>Valor total</th>
        </tr>
      </thead>
      <tbody>
        <?php
            $sql= mysqli_query($con,"SELECT * FROM tesouros");
            $valorTotal=0;
            foreach ($sql as $tesouro) {
              $icone=$tesouro['icone'];
              $nome=$tesouro['nome'];
              $valorUnitario=$tesouro['valorUnitario'];
              $quantidade=$tesouro['quantidade'];
              $total=$valorUnitario * $quantidade;
              $valorTotal+=$total;
              echo "<tr>
                <td><img src=$icone></td>
                <td>$nome</td>
                <td>".number_format($valorUnitario,0,",",".")."</td>
                <td>".number_format($quantidade,0,",",".")."</td>
                <td>".number_format($total,0,",",".")."</td>
              </tr>";
            }
         ?>

      </tbody>
      <tfoot>
        <tr>
          <td colspan="4">Total geral</td>
          <td><?php echo number_format($valorTotal,0,",","."); ?></td>
        </tr>
      </tfoot>
    </table>
    <p>Yarr Harr, marujo! Aqui é o temido Barba-Ruiva e você deve me ajudar
      a contabilizar os espólios das minhas aventuras!</p>
  </body>
</html>
